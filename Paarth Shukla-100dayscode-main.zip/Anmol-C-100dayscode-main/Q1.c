// q1.Write a program to input two numbers and display their sum.

#include <stdio.h>
int main(){
    int a, b; // initializing the variable.
    scanf("%d%d", &a, &b); // taking inputs from user. 
    printf("sum = %d", a + b); // printing the output.
    return 0;
}
